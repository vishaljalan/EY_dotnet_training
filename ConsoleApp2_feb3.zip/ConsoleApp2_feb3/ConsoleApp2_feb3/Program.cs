﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2_feb3
{
    internal class Add
    {
        int x, f;
        double y;
        String s;
        public Add(int a,double b)
        {
            x = a;
            y = b;
        }
        public Add(int a,String b)
        {
            f = a;
            s = b;
        }
        static void Main(string[] args)
        {


        }
    }
}
