Steps to open this file:

1)go to microsoft sql server management studio or any other sql database system
2)create a database. I used "LibraryTest"
3)go to query section: run the scripts given in the scripts folder
4)go to vs 2019 or newer
5)open the solution file from the Library folder
6)Scaffold from console using:
Scaffold-DbContext "Data Source=server_name;Initial Catalog=database_name;
Trusted_Connection=True;TrustServerCertificate=True" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models -force
7) go to context file in models: 
modify: ConnectionStrings":
{"DefaultConnection": "server_name;Initial Catalog=database_name;Trusted_Connection=True;TrustServerCertificate=True"}
8)in appsettings.json file: modify the default connection as above
9) in program.cs file:
 builder.Services.AddDbContext<EmployeeContext>
(options => options.UseSqlServer(builder.Configuration.GetConnectionString
("DefaultConnection")));

10)run this.

I have also provided the screenshots of the project.