USE [LibraryTest]
GO

/****** Object:  Table [dbo].[BorrowT]    Script Date: 13-02-2023 09:42:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[BorrowT](
	[BorrowId] [int] IDENTITY(1,1) NOT NULL,
	[TakenDate] [date] NULL,
	[StudentId] [int] NULL,
	[BookId] [int] NULL,
	[AuthorId] [int] NULL,
 CONSTRAINT [PK_BorrowT] PRIMARY KEY CLUSTERED 
(
	[BorrowId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[BorrowT]  WITH CHECK ADD FOREIGN KEY([AuthorId])
REFERENCES [dbo].[AuthorT] ([AuthorId])
GO

ALTER TABLE [dbo].[BorrowT]  WITH CHECK ADD FOREIGN KEY([BookId])
REFERENCES [dbo].[BookT] ([BookId])
GO

ALTER TABLE [dbo].[BorrowT]  WITH CHECK ADD FOREIGN KEY([StudentId])
REFERENCES [dbo].[StudentT] ([StudentId])
GO

