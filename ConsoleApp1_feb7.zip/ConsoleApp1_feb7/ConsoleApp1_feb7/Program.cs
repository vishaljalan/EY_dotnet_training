﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1_feb7
{
    internal class ListAndExceptions:ICurrentaccount
    {
        static void Main(string[] args)
        {

            try
            {
                var students=new List<string>();
                students.Add("abc");
                students.Add("efg");
                foreach(var student in students)
                {
                    Console.WriteLine(student+" ");
                }
                Console.WriteLine(students[5]);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
            Console.ReadLine();
        }

        public void AddNewAccount()
        {
            throw new NotImplementedException();
        }

        public void DisplayBalance()
        {
            throw new NotImplementedException();
        }
    }
}
