using WebApplication1_feb16.Models;
using WebApplication1_feb16.Controllers;
using WebApplication1_feb16.DataAccess;
using Moq;

namespace WebApplication1_feb16.Test
{
    //public class UnitTest1
    //{
    //    //add mock as handling all the functionalities
    //    public Mock<IMovie>mock=new Mock<IMovie>();

    //    [Fact]
    //    public void Test1()
    //    {

    //    }
    //    [Fact]
    //    public void getMovieByType() 
    //    {
    //        //arrange
    //        mock.Setup(p => p.GetMovieByType("action"));
    //        MovieController mov = new MovieController(mock.Object);

    //        //act
    //        var result = mov.Getmoviebytype("Action");

    //        //assert
    //        Assert.Equal(result, "action");
    //    }
    //}
}