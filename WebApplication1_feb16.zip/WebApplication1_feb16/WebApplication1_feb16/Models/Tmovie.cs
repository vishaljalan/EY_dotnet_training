﻿using System;
using System.Collections.Generic;

namespace WebApplication1_feb16.Models;

public partial class Tmovie
{
    public int Movieid { get; set; }

    public string? Moviename { get; set; }

    public string? Moviedir { get; set; }

    public string? Movietype { get; set; }
}
