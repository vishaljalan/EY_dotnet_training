﻿namespace WebApplication1_feb16.Models
{
    public class TmovieDTO
    {

        public int Movieid { get; set; }

        public string? Moviename { get; set; }

        public string? Moviedir { get; set; }

        public string? Movietype { get; set; }
    }
}
