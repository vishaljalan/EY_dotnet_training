﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ConsoleApp3_feb7.Program;

namespace ConsoleApp3_feb7
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //creating list with class as generic argument

             //Employee Employee1 = new Employee() { ID = 101, Name = "akash", Gender = "Male", Salary = 50000 };
             //List<Employee> listEmployees = new List<Employee>
             //{
             //   Employee1
             //};


            //better method
            var listEmployees = new List<Employee>();
            {
                listEmployees.Add(new Employee { ID = 1, Name = "akash", Gender = "male", Salary = 50000 });
              
            };
            foreach (var employee in listEmployees)
            {
                Console.WriteLine(employee.ID+" "+employee.Name+" "+employee.Gender+" "+employee.Salary);
            }
            Console.WriteLine(listEmployees);
            Console.ReadLine();
        }


    public class Employee
        {
            public int ID { get; set; }
            public string Name { get; set; }
            public string Gender { get; set; }
            public int Salary { get; set; }
        }
    }
}